<?php

    $host = "sql101.epizy.com";    /*localhost*/
    $db_user = "epiz_31838730";   /*root*/
    $db_password = "zMbrZ1tI5LSMQhz";
    $db_name = "epiz_31838730_epiz_31838730_";

?>